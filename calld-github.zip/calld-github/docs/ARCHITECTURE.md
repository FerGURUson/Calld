# Calld — System Architecture

**Created by Alexius Ferguson · Redemption Consulting LLC**

---

## Overview

Calld is a cross-organization volunteer marketplace built on four layers that progressively refine volunteer-to-role matching. The platform serves six user types across faith, fraternal, educational, nonprofit, and corporate sectors.

---

## The 4-Layer System

### Layer 1 — Database & Hour Tracking
The foundation. Every volunteer's time is tracked, attributed to specific organizations, and verifiable by coordinators. Hours can be used as:
- In-kind contributions for grant applications
- Match dollars for federal and foundation grants
- Service records for NHS, school requirements, college applications

### Layer 2 — Personality & Gifts Assessment
Volunteers complete an MBTI-based personality assessment via three paths:
1. Built-in 12-question conversational quiz
2. Manual type entry (select from all 16 types)
3. Link-out to 16personalities.com then import result

The result is stored as an MBTI code (e.g. ENFJ) and group (Diplomat, Analyst, Sentinel, Explorer).

### Layer 3 — Skills & Interest Matching
Volunteers select up to 5 interest categories from 9 structured buckets. Roles are tagged with a primary category. The system surfaces roles that match the volunteer's stated interests, and volunteers whose interests match open roles.

### Layer 4 — Find Me (Swipe Matching)
Both sides swipe. Volunteers browse open roles and swipe right on ones they're interested in. Coordinators browse matched volunteer profiles and swipe right on candidates they want. A mutual right swipe creates a Match and triggers an introduction.

---

## User Types

| Role | Description |
|------|-------------|
| Platform Admin | Full system access. Verifies orgs, manages flags, views audit log. |
| Head Coordinator | Full org access. Posts roles, browses volunteers, verifies hours, exports reports. |
| Sub-Coordinator | Access to assigned roles only. Cannot post roles or export. |
| Read-Only Viewer | View dashboards and reports only. No editing. |
| Volunteer | Own profile, swipe deck, hours tracking, matches. |
| Parent | Manages child (minor) volunteer profile and approvals. |

---

## Fit Score Algorithm

```
Score = (Personality × 0.40) + (Interest × 0.40) + (Availability × 0.20)
```

### Personality Score (40%)
- Exact MBTI type match = 100
- Same MBTI group (e.g. both Diplomats) = 70
- Different group = 40

### Interest Score (40%)
- Volunteer interest list contains role category = 100
- No match = 40

### Availability Score (20%)
- Volunteer hours_available ≥ role hours_per_week = 100
- Partial: (volunteer hours / role hours) × 100

---

## Security Architecture

### Org Verification
Organizations submit their EIN on registration. The platform is locked — no role posting, no volunteer browsing — until the Platform Admin manually verifies the EIN and sets `verified = true`.

### Minor Protection
- Age calculated from DOB at signup
- Under-18 volunteers cannot swipe directly
- "Request to Apply" sends ParentApproval record to parent
- Parent approves/denies — coordinator only visible after approval
- Minor profiles never shown to unverified orgs

### Role-Based Access
Server-side enforcement of permission tiers. Users cannot access dashboards outside their role via direct URL.

### Hours Integrity
Self-reported hours are marked `pending` until coordinator verification. Once verified, hours are locked and cannot be edited by the volunteer.

---

## Multi-Organization Design

One volunteer profile works across the entire Calld marketplace. Hours are attributed to each org separately. A volunteer active in a church, a fraternity, and a school board maintains:
- One identity and profile
- Separate hour records per org
- Separate match histories per org
- One exportable total service record

---

## Data Flow — Mutual Match

```
Volunteer swipes right on Role
    → Creates Swipe (volunteer, right, role)
    → System checks: does coordinator Swipe exist for this volunteer + role?
    → If YES: create Match record, fire notifications to both parties
    → If NO: wait for coordinator to swipe

Coordinator swipes right on Volunteer for Role
    → Creates Swipe (coordinator, right, volunteer, role)
    → System checks: does volunteer Swipe exist for this role?
    → If YES: create Match record, fire notifications to both parties
    → If NO: wait for volunteer to swipe
```
