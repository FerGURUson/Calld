# How to Track Downloads & Engagement on GitHub

GitHub doesn't count "downloads" like an app store, but here's how to track everything that matters.

---

## Built-In GitHub Analytics (Free)

Go to your repo → **Insights** tab

| Metric | Where to Find | What It Tells You |
|--------|---------------|-------------------|
| **Stars** | Insights → Stars | People who saved your repo — the #1 signal |
| **Forks** | Insights → Forks | Developers actively building with your code |
| **Clones** | Insights → Traffic | How many times the repo was downloaded (14-day window) |
| **Views** | Insights → Traffic | Unique visitors to your repo page |
| **Referring sites** | Insights → Traffic | Where people found you |
| **Popular content** | Insights → Traffic | Which files/pages get the most views |

**Note:** Clone data only shows the last 14 days. Check it weekly if you want historical data.

---

## README Badges (Already in Your README)

Your README already has live badges that show:
- ⭐ Current star count
- 🔀 Fork count
- 🐛 Open issues count

These update automatically — no setup needed.

---

## Ask for a Star in Your README

The most effective growth tactic for open source repos.
Already included at the bottom of your README:
> *"If Calld helped your community, give this repo a ⭐"*

---

## Optional: Star History Chart

Add this to your README to show growth over time:

```markdown
[![Star History Chart](https://api.star-history.com/svg?repos=alexiusferguson/calld&type=Date)](https://star-history.com/#alexiusferguson/calld&Date)
```

---

## Optional: Track Releases as Downloads

If you publish **Releases** (zip files of the project), GitHub counts downloads per release automatically. To see them:
- Go to your repo → **Releases**
- Click a release → scroll down to **Assets**
- Download count shows next to each file

To create your first release:
1. Go to your repo → **Releases** → **Draft a new release**
2. Tag it `v1.0.0`
3. Title: "Calld v1.0 — Initial Release"
4. Upload the project zip
5. Publish — GitHub tracks downloads from that point

---

## Share to Drive Traffic

The more places you share the repo link, the more stars and clones you get:

- LinkedIn post: "I open-sourced a volunteer matching platform I designed"
- Facebook/Instagram: tag faith orgs, nonprofits, school groups
- Reddit: r/nonprofit, r/volunteering, r/bubble, r/reactnative
- Product Hunt: submit as an open-source project
- Twitter/X: tag civic tech and social impact accounts
- UCF and IEL networks
- Words of Life Church community

---

*Created by Alexius Ferguson · Redemption Consulting LLC*
