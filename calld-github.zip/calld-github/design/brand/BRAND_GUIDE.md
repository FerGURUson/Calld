# Calld — Brand & Design System

**Created by Alexius Ferguson · Redemption Consulting LLC**

---

## Brand Identity

**Name:** Calld
**Tagline:** Called to Serve
**Sub-tagline:** Right Person · Right Role · Right Time

### Name Meaning
"Calld" carries spiritual undertones without being exclusive. Works across faith, fraternal, nonprofit, and corporate volunteer contexts. The dropped "e" signals a modern, app-native brand.

---

## Color Palette

| Name | Hex | Usage |
|------|-----|-------|
| Navy | `#0D1B2A` | Primary background, page backgrounds |
| Navy 2 | `#122236` | Card surfaces, nav bars, drawers |
| Navy 3 | `#1E3A5F` | Elevated surfaces, hover states |
| Cyan | `#00E5FF` | Primary accent — CTAs, highlights, logo glow |
| Teal | `#4DD9C0` | Secondary accent — gradient partner to cyan |
| White | `#FFFFFF` | Primary text on dark |
| Ice | `#E8F4F8` | Body text on dark |
| Steel | `#8AB4CC` | Subtext, labels, metadata |
| Slate | `#4D7A99` | Disabled, hints |
| Green | `#4CFF91` | Verified, active, success |
| Amber | `#FFB347` | Saved, shortlisted, warnings |
| Red | `#FF5C7A` | Pass action, errors, destructive |

### Glass Variables
```css
--glass:        rgba(255, 255, 255, 0.05);
--glass2:       rgba(255, 255, 255, 0.09);
--glass-border: rgba(0, 229, 255, 0.18);
--cyan-dim:     rgba(0, 229, 255, 0.12);
--cyan-glow:    rgba(0, 229, 255, 0.30);
```

---

## Typography

**Primary Font:** Barlow Condensed (headings, display, logo)
**Secondary Font:** Barlow (body, labels, buttons)
Both available free at [fonts.google.com](https://fonts.google.com)

| Style | Font | Size | Weight | Case |
|-------|------|------|--------|------|
| Display | Barlow Condensed | 42px+ | 800 | UPPERCASE |
| Heading | Barlow Condensed | 28–36px | 700 | UPPERCASE |
| Subheading | Barlow | 16–20px | 600 | Title |
| Label/Eyebrow | Barlow | 10–11px | 600 | UPPERCASE + letter-spacing |
| Body | Barlow | 14–15px | 400 | Normal |
| Small | Barlow | 11–12px | 300 | Normal |
| Button | Barlow | 14px | 700 | UPPERCASE |

---

## UI Style — Glassmorphism

All screens use a dark glassmorphic aesthetic:

- **Backgrounds:** Deep navy (`#0D1B2A`)
- **Cards:** Semi-transparent white fill with cyan-tinted border
- **Glow effects:** Cyan radial gradients at low opacity (4–8%)
- **Grid overlay:** Very subtle repeating line pattern at 2–3% opacity
- **CTAs:** Linear gradient from Teal to Cyan, navy text
- **Active states:** Cyan dim background + Cyan border

### CSS Pattern
```css
.glass-card {
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(0, 229, 255, 0.18);
  border-radius: 18px;
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
}

.btn-primary {
  background: linear-gradient(135deg, #4DD9C0, #00E5FF);
  color: #0D1B2A;
  border-radius: 100px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
}
```

---

## Logo Mark

The Calld logo is a **faceted diamond C** — a geometric hexagonal shape with inner polygon detail and a C letterform with a handshake/heart element. The mark represents:

- **Diamond:** Precision, value, clarity of purpose
- **Facets:** Multi-dimensional matching (personality + interest + availability)
- **C form:** Community, Called, Connection

### SVG Logo (use this in your build)
```svg
<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="lg1" x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse">
      <stop offset="0%" stop-color="#4dd9c0"/>
      <stop offset="100%" stop-color="#00e5ff"/>
    </linearGradient>
    <linearGradient id="lg2" x1="0" y1="48" x2="48" y2="0" gradientUnits="userSpaceOnUse">
      <stop offset="0%" stop-color="#00e5ff" stop-opacity="0.35"/>
      <stop offset="100%" stop-color="#4dd9c0" stop-opacity="0.12"/>
    </linearGradient>
  </defs>
  <polygon points="24,2 44,14 44,34 24,46 4,34 4,14" fill="url(#lg2)" stroke="url(#lg1)" stroke-width="1.5"/>
  <polygon points="24,7 39,16 39,32 24,41 9,32 9,16" fill="none" stroke="url(#lg1)" stroke-width="0.5" stroke-opacity="0.35"/>
  <path d="M30 17 Q22 14 18 20 Q14 26 18 32 Q22 38 30 35" stroke="url(#lg1)" stroke-width="2.5" fill="none" stroke-linecap="round"/>
  <circle cx="24" cy="24" r="2" fill="#00e5ff" opacity="0.6"/>
</svg>
```

---

## Attribution

All brand elements designed for the Calld project by **Alexius Ferguson**.
Logo concept generated with AI, refined for application.
MIT License — free to use with attribution.
