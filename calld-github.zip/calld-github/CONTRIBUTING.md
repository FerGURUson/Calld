# Contributing to Calld

First — thank you. Calld exists to solve a real problem in real communities. Every contribution matters.

---

## Ways to Contribute

### 🛠 Build It
- Pick up an open issue labeled `good first issue` or `help wanted`
- Build the Bubble.io version using the spec in `/bubble/BUBBLE_BRIEF.md`
- Build the Next.js web version (no one has started this yet — great opportunity)
- Improve the React Native scaffold in `/react-native/`

### 🧪 Test It
- Run the React Native scaffold and report bugs
- Review the Bubble brief and flag anything unclear or missing
- Pilot Calld with a real organization and share what you learn

### 📝 Document It
- Improve any doc in `/docs/`
- Write a setup guide for a specific stack
- Translate the README or Bubble brief into another language

### 💡 Shape It
- Open an issue to suggest a feature
- Share your use case — faith org, school, nonprofit, corporate
- Propose improvements to the fit score algorithm

---

## Getting Started

1. **Fork** the repository
2. **Clone** your fork: `git clone https://github.com/YOUR_USERNAME/calld.git`
3. **Create a branch**: `git checkout -b feature/your-feature-name`
4. **Make your changes**
5. **Commit**: `git commit -m "Add: brief description of what you did"`
6. **Push**: `git push origin feature/your-feature-name`
7. **Open a Pull Request** — describe what you built and why

---

## Issue Labels

| Label | Meaning |
|-------|---------|
| `good first issue` | Great for new contributors |
| `help wanted` | Actively looking for someone to take this |
| `bubble` | Related to the Bubble.io build |
| `react-native` | Related to the React Native build |
| `design` | UI/UX work |
| `documentation` | Docs improvements |
| `feature` | New feature proposal |
| `bug` | Something broken |
| `discussion` | Open for community input |

---

## Code Style

- Keep it readable over clever
- Comment anything non-obvious
- For React Native: follow existing file structure in `/react-native/src/`
- For Bubble: document any workflow logic in `/bubble/`
- Use the brand colors from `/design/brand/BRAND_GUIDE.md`

---

## Credit

All contributors are credited in the repository.
The original concept, architecture, and design remain credited to **Alexius Ferguson**.
The MIT license requires this credit to stay in all forks and distributions.

---

## Questions?

Open an issue labeled `discussion` — the community will help.
