# Calld — Bubble.io Developer Brief

**Created by Alexius Ferguson · Redemption Consulting LLC**
*Complete specification for building Calld on Bubble.io*

---

## Getting Started on Bubble

1. Go to [bubble.io](https://bubble.io) and create a free account
2. Create a new app — name it **Calld**
3. Follow this brief section by section
4. Build in the priority order in Section 10

Estimated build time with an experienced Bubble developer: **3–6 weeks**
Recommended plan to launch: **Bubble Starter ($29/mo)**

---

## Section 1 — Data Types

Create each Data Type in Bubble under **Data → Data Types**

### User *(extends Bubble's built-in User type)*
| Field | Type | Notes |
|-------|------|-------|
| full_name | text | Required |
| role | text | platform_admin / head_coordinator / sub_coordinator / read_only / volunteer / parent |
| date_of_birth | date | Used to calculate minor status |
| is_minor | yes/no | DOB > today minus 18 years |
| parent_user | User | Link to parent if minor |
| location | text | City, State |
| phone | text | Optional |
| avatar_url | text | Profile photo |
| onboarding_complete | yes/no | Default: no |

### VolunteerProfile
| Field | Type | Notes |
|-------|------|-------|
| user | User | Link to User |
| mbti_type | text | e.g. ENFJ |
| mbti_group | text | Analyst / Diplomat / Sentinel / Explorer |
| interests | list of text | Up to 5 category IDs |
| bio | text | Short personal bio |
| hours_available_per_week | number | Weekly availability |
| schedule_preferences | list of text | Weekdays / Weekends / Evenings |
| total_verified_hours | number | Sum of all verified hours |
| is_active | yes/no | Default: yes |

### Organization
| Field | Type | Notes |
|-------|------|-------|
| name | text | Required |
| type | text | Faith-Based / Fraternal / School / Nonprofit / Corporate / Government / Healthcare / Other |
| ein | text | Required for verification |
| mission | text | Mission statement |
| location | text | City, State |
| contact_email | text | Primary contact |
| logo_url | text | Org logo |
| website | text | Optional |
| verified | yes/no | Default: no — set by Admin only |
| pending_review | yes/no | Default: yes after submission |
| active | yes/no | Default: yes after verification |

### Role
| Field | Type | Notes |
|-------|------|-------|
| organization | Organization | Link to Org |
| created_by | User | Coordinator |
| title | text | Role title |
| category | text | Interest category ID |
| description | text | Full description |
| hours_per_week | number | Time commitment |
| schedule | text | Weekdays / Weekends / Flexible |
| mbti_types | list of text | Ideal personality types |
| skills_needed | list of text | Required skills |
| volunteers_needed | number | How many needed |
| volunteers_filled | number | How many matched |
| start_date | date | Optional |
| active | yes/no | Default: yes |
| filled | yes/no | Default: no |
| minors_allowed | yes/no | Default: no |

### HoursLog
| Field | Type | Notes |
|-------|------|-------|
| volunteer_profile | VolunteerProfile | Link |
| organization | Organization | Hours attributed to |
| role | Role | Optional |
| hours | number | Decimal allowed (2.5) |
| date | date | Date of service |
| description | text | What they did |
| status | text | pending / verified / rejected |
| verified_by | User | Coordinator who verified |
| verified_at | date | Timestamp |
| in_kind_value | number | hours × hourly rate |

### Swipe
| Field | Type | Notes |
|-------|------|-------|
| swiper_user | User | Who swiped |
| swiper_type | text | volunteer or coordinator |
| volunteer_profile | VolunteerProfile | The volunteer |
| role | Role | The role |
| direction | text | left or right |
| created_date | date | Auto current date |

### Match
| Field | Type | Notes |
|-------|------|-------|
| volunteer_profile | VolunteerProfile | |
| role | Role | |
| organization | Organization | |
| status | text | matched / active / completed / cancelled |
| matched_date | date | |
| fit_score | number | 0–100 |

### Message
| Field | Type | Notes |
|-------|------|-------|
| match | Match | Which match thread |
| sender | User | Who sent it |
| content | text | Message body |
| read | yes/no | Default: no |
| sent_date | date | Auto current date |

### ParentApproval
| Field | Type | Notes |
|-------|------|-------|
| parent_user | User | |
| minor_user | User | |
| role | Role | Requested role |
| organization | Organization | |
| status | text | pending / approved / denied |
| requested_date | date | |
| responded_date | date | |
| notes | text | Optional parent notes |

---

## Section 2 — Pages

### Authentication
| Page | Slug | Description |
|------|------|-------------|
| Welcome | `/` | Two CTAs: "I want to volunteer" and "I represent an organization" |
| Sign Up | `/signup` | Email, password, full name, DOB. If DOB < 18 years ago → parent flow |
| Sign In | `/login` | Email + password. Route by user.role after login |
| Reset Password | `/reset` | Bubble built-in reset |

### Volunteer
| Page | Slug | Description |
|------|------|-------------|
| Volunteer Home | `/volunteer/home` | Profile completion %, recent matches, pending hours, suggested roles |
| Assessment | `/volunteer/assessment` | 3 paths: quiz / manual type entry / link to 16personalities.com |
| Interests | `/volunteer/interests` | 9 tiles, max 5 selectable, MBTI nudge, subtags |
| Swipe Deck | `/volunteer/discover` | Role cards, swipe right = interest, swipe left = pass |
| Hours Dashboard | `/volunteer/hours` | Log hours, view by org, pending/confirmed totals |
| My Matches | `/volunteer/matches` | Mutual matches, tap to message |
| Profile | `/volunteer/profile` | Edit bio, photo, availability, interests |
| Org Directory | `/orgs` | Browse verified orgs, filter by type, join |

### Coordinator
| Page | Slug | Description |
|------|------|-------------|
| Coordinator Home | `/coordinator/home` | Open roles, pending hours, recent matches |
| Org Setup | `/coordinator/setup` | Name, type, EIN, logo, mission — locked until verified |
| Post a Role | `/coordinator/roles/new` | All role fields including MBTI types and minors toggle |
| Role Management | `/coordinator/roles` | Active/filled/archived roles, edit, match counts |
| Swipe Deck | `/coordinator/browse` | Volunteer cards with fit score, filters, swipe mechanic |
| Hours Verification | `/coordinator/hours` | Pending hours list, approve/reject |
| Reports & Export | `/coordinator/reports` | Filter, summary table, in-kind calculator, PDF export |
| Team Management | `/coordinator/team` | Invite sub-coordinators and read-only viewers |

### Parent
| Page | Slug | Description |
|------|------|-------------|
| Parent Home | `/parent/home` | All child profiles, hours, pending approvals |
| Add Child | `/parent/child/new` | Name, DOB, photo, link to parent |
| Approvals | `/parent/approvals` | Pending role requests, approve/deny |
| Minor Hours | `/parent/hours` | Hours by child by org, PDF export |

### Admin
| Page | Slug | Description |
|------|------|-------------|
| Admin Dashboard | `/admin` | Platform stats, pending EINs, flagged accounts |
| Org Verification | `/admin/orgs` | Review and approve/reject organizations |
| User Management | `/admin/users` | Search, suspend, delete users |
| Audit Log | `/admin/audit` | Read-only action log |

---

## Section 3 — Key Workflows

### Mutual Match Detection
*Trigger: coordinator swipes right*
1. Create Swipe (coordinator, right, volunteer, role)
2. Search: does volunteer Swipe exist for same volunteer + role + direction = right?
3. If found → create Match record (status = matched, calculate fit_score)
4. Show Match popup to coordinator
5. Send push notification to volunteer
6. Send push notification to coordinator

### Fit Score Formula
```
Score = (Personality × 0.40) + (Interest × 0.40) + (Availability × 0.20)

Personality:  role.mbti_types contains volunteer.mbti_type → 100
              same group → 70
              different → 40

Interest:     volunteer.interests contains role.category → 100
              no match → 40

Availability: volunteer.hours_available ≥ role.hours_per_week → 100
              partial: (volunteer hours ÷ role hours) × 100
```
Use the **Toolbox plugin** to run this as custom JavaScript in a workflow.

### Minor Role Request
*Trigger: minor taps "Request to Apply"*
1. Create ParentApproval (status = pending)
2. Send email to parent: "[Child] wants to volunteer at [Org]"
3. Send push notification to parent
4. Show confirmation to minor

### Parent Approves
*Trigger: parent taps Approve*
1. Update ParentApproval status = approved
2. Create volunteer Swipe (direction = right) for the minor
3. Check for mutual match (run match workflow)
4. Notify minor

### Verify Hours
*Trigger: coordinator approves HoursLog*
1. Update HoursLog status = verified
2. Recalculate volunteer total_verified_hours
3. Notify volunteer

---

## Section 4 — Privacy Rules

Set these under **Data → Privacy** for each type.

| Type | View Rule | Modify Rule |
|------|-----------|-------------|
| User | Current user = this user | Current user = this user |
| VolunteerProfile | Owner OR coordinator of affiliated org | Owner only |
| Organization | verified = yes (public) | Head coordinator of org |
| Role | active = yes (public) | Coordinator of org |
| HoursLog | Owner OR coordinator of org | Owner (pending only) |
| Match | Volunteer or coordinator in match | System only |
| Message | Sender or match participant | Sender only |
| ParentApproval | Parent or minor or org coordinator | Parent (status field) |

---

## Section 5 — Recommended Plugins

| Plugin | Purpose |
|--------|---------|
| Air Native Swipe | Swipe left/right card mechanic |
| PDF Conjurer | Generate grant-ready PDF reports |
| Toolbox | Run JavaScript for fit score calculation |
| Air Date Picker | Clean date inputs |
| Bubble Tea Charts | Hours summary charts |
| Rich Text Editor | Role and mission descriptions |

---

## Section 6 — Build Priority

**Phase 1 (Week 1–2):** Data types, Auth, Volunteer onboarding, Org setup, Admin EIN approval

**Phase 2 (Week 2–3):** Both swipe decks, fit score workflow, mutual match detection, match popup

**Phase 3 (Week 3–4):** Hours logging, verification dashboard, PDF export

**Phase 4 (Week 4–5):** Message threads, parent/minor flow, approval workflow

**Phase 5 (Week 5–6):** Push notifications, org directory, profile editing, privacy audit, pilot launch

---

*Brief created by Alexius Ferguson · Redemption Consulting LLC · MIT License*
