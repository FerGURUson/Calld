# CALLD — Called to Serve

> **Right Person · Right Role · Right Time**

[![License: MIT](https://img.shields.io/badge/License-MIT-00e5ff.svg)](LICENSE)
[![Stars](https://img.shields.io/github/stars/alexiusferguson/calld?style=social)](https://github.com/alexiusferguson/calld)
[![Forks](https://img.shields.io/github/forks/alexiusferguson/calld?style=social)](https://github.com/alexiusferguson/calld/network/members)
[![Issues](https://img.shields.io/github/issues/alexiusferguson/calld)](https://github.com/alexiusferguson/calld/issues)
[![Made with Love](https://img.shields.io/badge/Made%20with-%E2%9D%A4-ff5c7a.svg)](https://github.com/alexiusferguson/calld)

---

## The Problem

Every faith community, fraternity, school, and nonprofit faces the same silent crisis:

**The warm body approach to volunteering.**

Someone needs a task done. They grab whoever is available — not whoever is *right* for it. That volunteer gets placed in a role that doesn't fit their personality, skills, or interests. They show up a few times. They burn out. They disappear.

The organization suffers. The volunteer feels guilty. The community loses.

**Calld was built to fix this.**

---

## What is Calld?

Calld is an open-source, cross-organization volunteer marketplace that matches volunteers to roles based on:

- 🧠 **Personality type** (MBTI-based assessment)
- 🎯 **Interests** (structured category matching)
- ⏱ **Availability** (hours and schedule preferences)

Think **Hinge for volunteer work** — both volunteers and coordinators swipe, and a mutual match triggers an introduction. No forced placements. No guesswork. Just the right person in the right role.

---

## The 4-Layer Architecture

```
┌─────────────────────────────────────────────────────┐
│  LAYER 4 · FIND ME                                  │
│  Swipe-based matching — volunteer meets role        │
├─────────────────────────────────────────────────────┤
│  LAYER 3 · INTERESTS                                │
│  9 category buckets — skills meet passion           │
├─────────────────────────────────────────────────────┤
│  LAYER 2 · PERSONALITY & GIFTS                      │
│  MBTI assessment — understand how you're wired      │
├─────────────────────────────────────────────────────┤
│  LAYER 1 · DATABASE & HOUR TRACKING                 │
│  Verified hours — usable as in-kind grant match     │
└─────────────────────────────────────────────────────┘
```

---

## Who It's For

Calld is built for **any organization that relies on volunteers:**

| Sector | Examples |
|--------|----------|
| ⛪ Faith-Based | Churches, mosques, synagogues, ministry orgs |
| 🤝 Fraternal | Greek-letter orgs, service fraternities, civic leagues |
| 🏫 Education | Schools, PTAs, after-school programs, tutoring networks |
| 🌍 Nonprofit | Community orgs, food banks, social services |
| 🏢 Corporate | Employee volunteer programs, CSR initiatives |

---

## Key Features

### For Volunteers
- 🧠 Personality assessment (built-in quiz or 16Personalities link-out)
- 🎯 Interest tag selection across 9 categories
- 📱 Swipe deck to browse open roles
- ⏱ Hours dashboard — log and track service hours
- 💙 Match notifications and in-app messaging
- 🏛 Multi-org support — one profile, multiple affiliations

### For Coordinators
- 📋 Post and manage volunteer roles
- 🔍 Browse matched volunteers with fit scores (0–100%)
- ✅ Verify volunteer hours for grant reporting
- 📄 Export grant-ready PDF reports
- 👥 Team management with role-based access
- 🔐 EIN-verified org trust layer

### For Parents (Minor Volunteers)
- 👨‍👧 Parent-controlled accounts for under-18 volunteers
- ✅ Approve or deny role applications
- 📊 Track child's hours for NHS, school service requirements
- 🛡 Safety guardrails — minors only visible to verified orgs

### For Platform Admins
- 👑 EIN verification queue
- 🔐 Full audit log
- 📊 Platform-wide analytics

---

## The Fit Score Algorithm

Every volunteer-role pairing generates a Fit Score (0–100):

```
Fit Score = (Personality Match × 0.40)
          + (Interest Match   × 0.40)
          + (Availability     × 0.20)
```

| Component | 100 pts | 70 pts | 40 pts |
|-----------|---------|--------|--------|
| Personality | Exact MBTI match | Same MBTI group | Different group |
| Interest | Category match | — | No match |
| Availability | Hours available ≥ hours needed | Partial | Under capacity |

---

## Permission Hierarchy

```
👑 Platform Admin      — Full system access
   └── 🏢 Head Coordinator  — Full org access
       ├── 📋 Sub-Coordinator    — Assigned roles only
       └── 👁  Read-Only Viewer   — Reports & dashboards only

🙋 Volunteer           — Own profile + discovery
👨‍👧 Parent              — Child profile management
```

---

## Interest Categories

| ID | Category | Icon |
|----|----------|------|
| `youth` | Youth & Education | 🎓 |
| `outreach` | Outreach & Events | 🌍 |
| `spiritual` | Spiritual Care | ✝️ |
| `comms` | Comms & Marketing | 📣 |
| `admin` | Admin & Operations | 📋 |
| `finance` | Finance & Accounting | 💰 |
| `tech` | Tech & IT | 💻 |
| `trades` | Skilled Trades | 🔧 |
| `legal` | Legal & Compliance | ⚖️ |

---

## Build Options

Calld is stack-agnostic. The architecture and database schema work across multiple platforms:

### Option A — Bubble.io (No-Code)
Fastest path to a working pilot. Full spec in [`/bubble/BUBBLE_BRIEF.md`](bubble/BUBBLE_BRIEF.md).
- Estimated build time: 3–6 weeks with a Bubble developer
- Estimated cost: $2,000–$5,000 on Upwork/Fiverr
- Bubble plan: Free to build, $29/mo to launch

### Option B — React Native + Expo + Supabase
Mobile-first production app. Full scaffold in [`/react-native/`](react-native/).
- Stack: React Native, Expo, Supabase, Zustand
- Run on iOS and Android from one codebase
- Supabase schema in [`/supabase/schema.sql`](supabase/schema.sql)

### Option C — Web App (Next.js + Supabase)
Web-first with mobile-responsive design.
- Stack: Next.js, Tailwind CSS, Supabase
- Coming soon — open an issue if you want to lead this

---

## Repository Structure

```
calld/
├── README.md                    ← You are here
├── LICENSE                      ← MIT — free to use with attribution
├── CONTRIBUTING.md              ← How to get involved
│
├── docs/
│   ├── ARCHITECTURE.md          ← Full system architecture
│   ├── DATA_MODEL.md            ← Complete data model reference
│   ├── WORKFLOWS.md             ← Key workflow logic (matching, approval, etc.)
│   ├── DESIGN_SYSTEM.md         ← Colors, typography, UI guidelines
│   └── SECURITY.md              ← Privacy rules and security requirements
│
├── bubble/
│   └── BUBBLE_BRIEF.md          ← Complete Bubble.io developer specification
│
├── design/
│   ├── wireframes/              ← HTML interactive prototypes
│   │   ├── assessment.html      ← Personality assessment screen
│   │   ├── interests.html       ← Interest selection screen
│   │   ├── profile-card.html    ← Volunteer profile card
│   │   └── swipe-deck.html      ← Coordinator swipe deck
│   └── brand/
│       └── BRAND_GUIDE.md       ← Logo, colors, typography
│
├── supabase/
│   └── schema.sql               ← Complete database schema (paste into Supabase)
│
└── react-native/                ← React Native + Expo project scaffold
    ├── App.tsx
    ├── package.json
    └── src/
        ├── constants/
        ├── services/
        ├── store/
        ├── navigation/
        └── screens/
```

---

## Quick Start

### Using the Bubble brief
1. Read [`/bubble/BUBBLE_BRIEF.md`](bubble/BUBBLE_BRIEF.md) — it has everything
2. Post on Upwork or Fiverr: *"Build Calld volunteer platform on Bubble.io using provided spec"*
3. Attach the brief document from [`/bubble/`](bubble/)

### Using the React Native scaffold
```bash
# Clone the repo
git clone https://github.com/alexiusferguson/calld.git
cd calld/react-native

# Install dependencies
npm install

# Add your Supabase credentials
# Open src/services/supabase.ts and paste your URL + anon key

# Run on your phone via Expo Go
npx expo start
```

---

## Roadmap

- [x] Architecture design
- [x] Database schema
- [x] Fit score algorithm
- [x] Interactive UI prototypes
- [x] React Native scaffold
- [x] Bubble.io developer brief
- [ ] Bubble.io reference build
- [ ] Next.js web version
- [ ] Push notification service
- [ ] PDF export engine
- [ ] Live pilot with partner org
- [ ] App Store submission guide

---

## Contributing

All skill levels welcome. See [CONTRIBUTING.md](CONTRIBUTING.md) for how to get involved.

Not a developer? You can still contribute:
- ⭐ **Star this repo** — helps others find it
- 🔀 **Share it** — tag an org, a developer, or a community leader who needs this
- 💬 **Open an issue** — suggest features, report gaps, share your use case
- 🧪 **Pilot it** — if you run an org, reach out to test Calld with real volunteers

---

## Creator

**Calld was conceived, designed, and architected by:**

**Alexius Ferguson, M.Ed**
Assistant Director — UCF Center for Community Schools
Founder — Redemption Consulting LLC
**FerGURUson · Strategic Intelligence**
*"Where Passion Meets Expertise"*

> *"The warm body approach to volunteering is silent organizational suicide. Calld exists to end it."*
> — Alexius Ferguson

---

## License

MIT License — free to use, modify, and distribute.
**Required:** Keep the copyright notice and credit to Alexius Ferguson in all copies.

See [LICENSE](LICENSE) for full terms.

---

*If Calld helped your community, give this repo a ⭐ — it's the best way to say thank you.*
