---
name: Pilot Organization
about: Tell us you're using Calld with a real organization
title: '[PILOT] '
labels: discussion
assignees: ''
---

## About your organization
- Name:
- Type: [ ] Faith  [ ] Fraternal  [ ] School  [ ] Nonprofit  [ ] Corporate  [ ] Other
- Location:
- Approx. number of volunteers:

## Which build are you using?
- [ ] Bubble.io
- [ ] React Native
- [ ] Building our own

## What are you hoping Calld solves for you?

## What would you need to get started?

## Can we feature your pilot in the README?
- [ ] Yes
- [ ] No
