---
name: Bug Report
about: Something isn't working right
title: '[BUG] '
labels: bug
assignees: ''
---

## What happened?
A clear description of the bug.

## Steps to reproduce
1. Go to...
2. Click...
3. See error

## Expected behavior
What should have happened.

## Environment
- Build type: [ ] Bubble  [ ] React Native  [ ] Other
- Device/Browser:
- Version/commit:

## Screenshots
If applicable, add screenshots.
