---
name: Feature Request
about: Suggest something new for Calld
title: '[FEATURE] '
labels: feature
assignees: ''
---

## What problem does this solve?
Describe the gap or pain point.

## Who does it help?
- [ ] Volunteer
- [ ] Coordinator
- [ ] Parent
- [ ] Platform Admin
- [ ] All users

## Proposed solution
How you imagine this working.

## Which build does this apply to?
- [ ] Bubble.io
- [ ] React Native
- [ ] Both
- [ ] Not sure

## Additional context
Any mockups, examples, or references.
